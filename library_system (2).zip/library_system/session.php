<html>
<head>
	</head>
	 </style>
	<body>

		<!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->

		<?php
         session_start();
		 error_reporting(0);

         $username=$_SESSION['username'];
         $password=$_SESSION['password'];


         $session=isset($username) && isset($password)?true:false;

         if($session==false)
         {
         	header('location:./login.html');
         }

		?>



		</body>

	</html>