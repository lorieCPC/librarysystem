<?php
    require_once("./database_info.php");

    class DbConnection{
        private $con;

        function __construct()
        {
            $this->con = new mysqli(SERVER,username,password,database);
        }

        function dbStatus(){
            if(!mysqli_connect_errno())
                return 1;
            else
                return mysqli_connect_errno();
        }
        function getCon(){
            return $this->con;
        }
        function dbClose(){
            $this->con->close();
        }

        function getData($user)
        {
            return $this->con->query($user);
        }
    }
?>