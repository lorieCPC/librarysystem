<?php
require_once("./connect.php");

session_start();

 $method = $_POST['method'];
    if(function_exists($method)){
        call_user_func($method);
    }

switch ($method){


	case 'ReserveBook':

	 $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

            $bookid=$_POST['bookid'];
            $username=$_POST['username'];
            $title=$_POST['title'];
            $price=$_POST['price'];
            $reservedate=$_POST['date'];
            $days=$_POST['days'];
            $fee=$price*$days;
            $status="Pending";
            $check=0;
           
         

         
        
         $sql = "INSERT INTO `book_reservation` (book_id,costumer_username,book_title,book_price,date_reservation,total_fee, days, status) VALUES ('$bookid', '$username', '$title', '$price', '$reservedate', '$fee', '$days', '$status')";
         
          $reserve = "UPDATE `book_information` SET book_status='$status' WHERE book_id=$bookid";
       
        if($db->query($sql)===true && $db->query($reserve)){                  
                $con->dbClose();
                echo 1;
        }
        else{
             $con->dbClose();
            echo 0;
        }
}

	break;//End


case 'UpdateReservation':
 $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();
 
       $reservationid=$_POST['reservation_id'];
       $booktitle=$_POST['book_title'];
       $bookprice=$_POST['book_price'];
       $reserve=$_POST['reserve'];
       $days=$_POST['days'];
       $fee=$bookprice*$days;
       $username=$_POST['costumer_name'];
       $stats="Pending";

        $sql = "UPDATE `book_reservation` SET book_title='$booktitle',book_price='$bookprice',date_reservation='$reserve',days='$days',total_fee='$fee',status='$stats' WHERE reservation_id=$reservationid";
        

        if ($db->query($sql)===true) {

            echo 1;

        }

        else {

             echo 0;

        }

        $con->dbClose();

    }

  
   break;

   case 'CancelReservation':

   $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();


        $id=$_POST['id_reservation'];
        $bookid=$_POST['book_id'];
        $status="Free";


        $sql = "DELETE FROM `book_reservation` WHERE reservation_id=$id ";
         $reserve ="UPDATE `book_information` SET book_status='$status' WHERE book_id=$bookid";


        if ($db->query($sql)===true && $db->query($reserve)===true) {

            echo 1;

        }

        else {

            echo 0;

        }

        $con->dbClose();

    }
    break;

    case 'AcceptRequest':

    $bookid=$_POST['book_id'];

   $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

            $status="Reserved";
             $sql ="UPDATE `book_reservation` SET status='$status' WHERE book_id=$bookid";
             $stats ="UPDATE `book_information` SET book_status='$status' WHERE book_id=$bookid";

             if ($db->query($sql)===true && $db->query($stats)===true) {

            echo 1;

        }

        else {

            echo 0;

        }

        $con->dbClose();

    }

    break;

     case 'DeclineRequest':

    $bookid=$_POST['book_id'];
    $reserve_id=$_POST['reserveid'];

   $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

            $status="Free";
             $sql ="DELETE FROM `book_reservation` WHERE reservation_id=$reserve_id";
             $stats ="UPDATE `book_information` SET book_status='$status' WHERE book_id=$bookid";

             if ($db->query($sql)===true && $db->query($stats)===true) {

            echo 1;

        }

        else {

            echo 0;

        }

        $con->dbClose();

    }

    break;


    case 'BorrowedBook':

     $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

     
     $reservation_id=$_POST['reservationid'];
     $reservation_date=$_POST['reservationdate'];
     $book_id=$_POST['book_id'];
     $book_title=$_POST['book_title'];
     $book_price=$_POST['book_price'];
     $days=$_POST['days'];
     $total_fee=$_POST['total_fee'];
     $costumer_username=$_POST['costumer_user'];
     $status="Unreturn";

      $sql = "INSERT INTO `book_borrowed` (costumer_username,book_id,book_title,book_price,date_borrowed,days,total_fee,status) VALUES ('$costumer_username', '$book_id', '$book_title', '$book_price', '$reservation_date', '$days', '$total_fee', '$status')";
      $delete ="DELETE FROM `book_reservation` WHERE reservation_id=$reservation_id";
       $stats ="UPDATE `book_information` SET book_status='Not Free' WHERE book_id=$book_id";


        if ($db->query($sql)===true && $db->query($delete)===true &&  $db->query($stats)===true) {

            echo 1;

        }

        else {

            echo 0;

        }

        $con->dbClose();



        }

   break;

   case 'ReturnBook':

      $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

            $borrowid=$_POST['borrow_id'];
            $totalfee=$_POST['totalfee'];
            $bookid=$_POST['bookid'];
            $amount=$_POST['amount'];
            $librarian=$_POST['librarian'];
            $date = date('y-m-d');
         

            if($amount<$totalfee)
            {
                echo -1;
            }
            else{
                  $sql ="UPDATE `book_information` SET book_status='Free' WHERE book_id=$bookid";
                  $stats="UPDATE `book_borrowed` SET status='Return',date_returne='$date',librarian_username='$librarian' WHERE borrowed_id=$borrowid";

                  if ($db->query($sql)===true && $db->query($stats)===true ) {

                   $changes=$amount-$totalfee; 
                   echo($changes);
               }

                   else {

                echo -2;

        }

            }

             $con->dbClose();

          }
  
break;

//switch case end
}











?>