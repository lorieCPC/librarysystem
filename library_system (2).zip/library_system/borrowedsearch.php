<?php

 $search = $_POST['search'];

  header("Location:./borrowed.php?search=".$search);

?>