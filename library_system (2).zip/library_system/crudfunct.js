$(document).on('click','#edit',function(e) {

        var id1=$(this).attr("data-id1");

        var title=$(this).attr("data-title");

        var publisher=$(this).attr("data-publisher");

        var writer=$(this).attr("data-writer");

        var department=$(this).attr("data-department");

        var price=$(this).attr("data-price");

        var rack=$(this).attr("data-rack");

        var status=$(this).attr("data-status");


        $('#id').val(id1);

        $('#title').val(title);

        $('#publisher').val(publisher);

        $('#writer').val(writer);

        $('#department').val(department);

        $('#price').val(price)

        $('#rack').val(rack);

        $('#status').val(status);
      

    });



$(document).on('click','#reserve',function(e) {

  var id=$(this).attr("data-id");
  var title=$(this).attr("data-title");
  var price=$(this).attr("data-price");
 
  $('#bookid').val(id);
   $('#title').val(title);
    $('#price').val(price);


});//End

function Reserve(event)
{
 var data = new FormData(event.target);
    data.append("method","ReserveBook");
    axios.post("./transactionswitchcase.php",data)
    .then(function(response){
        if(response.data ==1){
            Swal.fire('Success', 'Book Reserve')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./shop.php";
                  }
              })
                   
         } 
        else{
            var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })

}

//update reservation getting data
$(document).on('click','#icon_reserve',function(e) {

        var id=$(this).attr("data-reserveid");

        var title=$(this).attr("data-booktitle");

        var price=$(this).attr("data-bookprice");

        var username=$(this).attr("data-costumeruser");

        $('#costumer_name').val(username);
        
        $('#reservation_id').val(id);

        $('#book_title').val(title);

        $('#book_price').val(price);

    });

//saving data to update reservation
function UpdateReservation(event){
     
    var data = new FormData(event.target);
    data.append("method","UpdateReservation");
    axios.post("./transactionswitchcase.php",data)
    .then(function(response){
        if(response.data ==1){
            Swal.fire('Success', 'Reservation Updated')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./profile.php";
                  }
              })                  
         }
              
        else{
            var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })
}//end

//cancel reservation
$(document).on("click", "#icon_cancel", function() {

        var id=$(this).attr("data-idreserve");
         var username=$(this).attr("data-costumer");
         var bookid=$(this).attr("data-bookid");
        $('#id_reservation').val(id); 
        $('#costumer').val(username); 
        $('#book_id').val(bookid);

    });//End

$(document).on("click", "#acceptrequest", function() {

        var id=$(this).attr("data-book");
        var data=new FormData();
        data.append("book_id",id);
        data.append("method","AcceptRequest");

         axios.post("./transactionswitchcase.php",data)
    .then(function(response){
        if(response.data ==1){
            Swal.fire('Success', 'Reservation Accept')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./request.php";
                  }
              })
                   
         }
              
        else{
            var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })


    });//End


$(document).on("click", "#declinerequest", function() {

        var id=$(this).attr("data-book");
        var reservation_id=$(this).attr("data-reserveid");
        var data=new FormData();
        data.append("book_id",id);
        data.append("reserveid",reservation_id);
        data.append("method","DeclineRequest");

         axios.post("./transactionswitchcase.php",data)
    .then(function(response){
        if(response.data ==1){
            Swal.fire('Success', 'Reservation Decline')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./request.php";
                  }
              })
                   
         }
              
        else{
            var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })


    });//End


$(document).on("click", "#borrowed", function() {

        var reservation=$(this).attr("data-reservationdate");
        var reservationid=$(this).attr("data-reservationid");
        var bookid=$(this).attr("data-bookid");
        var booktitle=$(this).attr("data-booktitle");
        var bookprice=$(this).attr("data-bookprice");
        var days=$(this).attr("data-days");
        var total=$(this).attr("data-totalfee");
        var costumeruser=$(this).attr("data-costumeruser");

        var data=new FormData();
        data.append("reservationdate",reservation);
        data.append("reservationid",reservationid);
        data.append("book_id",bookid);
        data.append("book_title",booktitle);
        data.append("book_price",bookprice);
        data.append("days",days);
        data.append("total_fee",total);
        data.append("costumer_user",costumeruser);
        data.append("method","BorrowedBook");

         axios.post("./transactionswitchcase.php",data)
    .then(function(response){
        if(response.data ==1){
            Swal.fire('Success')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./borrowed.php";
                  }
              })
                   
         }
              
        else{
            var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })


   });//End






//cancel reservation
function CancelReservation(event){
     
    var data = new FormData(event.target);
    data.append("method","CancelReservation");
    axios.post("./transactionswitchcase.php",data)
    .then(function(response){
        if(response.data ==1){
            Swal.fire('Success', 'Reservation Cancel')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./profile.php";
                  }
              })
                   
         }
              
        else{
            var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })
}//end

//create new admin
function CreateAdmin(event){
   
    var pass= document.getElementById('password').value ;
    var check=CheckPassword(pass);
   

    if(check==true)
    {
    var data = new FormData(event.target);
    data.append("method","CreateAdmin");
    axios.post("./switchcase.php",data)
    .then(function(response){
        if(response.data == 1){
            Swal.fire('Success', 'New Admin Created')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./admin_login.html";
                  }
              })
                   
         }
         else if(response.data ==2){
             Swal.fire({icon: 'error',text: 'Username already existed'})
              Clearform2();     

         }
         else if (response.data ==3)
         {
           Swal.fire({icon: 'error',text: 'This email is already in used'})
              Clearform2(); 
         }
              
        else{
            var data=response.data;
            alert("Error not saving");
        }

          })
}
else
{
    Swal.fire({icon: 'error',text: 'Invalid Password'})
    ClearPass();
}
}//end

function Clearform2()
{
  document.getElementById('lastname').value='';
  document.getElementById('firstname').value='';
  document.getElementById('mname').value='';
  document.getElementById('address').value='';
  document.getElementById('gender').value='';
  document.getElementById('adminemail').value='';
  document.getElementById('contact').value='';
  document.getElementById('adminusername').value='';
  document.getElementById('password').value='';
}


 function Update(event){
     
    var data = new FormData(event.target);
    data.append("method","UpdateBook");
    axios.post("./switchcase.php",data)
    .then(function(response){
        if(response.data ==1){
            Swal.fire('Success!', 'Book Updated')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./editbook.php";
                  }
              })
                   
         }
              
        else{
            var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })
}//end



//DeleteBook
$(document).on("click", "#delet", function() {

        var id2=$(this).attr("data-id2");

        $('#id_d').val(id2);  

               

    });//End

//ReturnBook
$(document).on("click", "#btnreturn", function() {

        var borrowid=$(this).attr("data-borrowid");
         var bookid=$(this).attr("data-bookid");
        var booktitle=$(this).attr("data-booktitle");
         var costumer=$(this).attr("data-costumer");
        var bookprice=$(this).attr("data-bookprice");
         var days=$(this).attr("data-days");
        var totalfee=$(this).attr("data-totalfee");



        $('#borrow_id').val(borrowid); 
           $('#bookid').val(bookid);
            $('#booktitle').val(booktitle);
             $('#costumer').val(costumer);
              $('#price').val(bookprice);
               $('#days').val(days);
                $('#totalfee').val(totalfee);

               

    });//End


//Returnbook
function ReturnBook(event){
     
    var data = new FormData(event.target);
    data.append("method","ReturnBook");
    axios.post("./transactionswitchcase.php",data)
    .then(function(response){
        if(response.data >=0){
            var data=response.data;
            Swal.fire('Changes: '+data)
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./returnbook.php";
                  }
              })
                   
         }            
        else if(response.data==-1) {
            var data=response.data;
            Swal.fire('Warning', 'Invalid Amount')
        }

        else  {
            var data=response.data;
            Swal.fire('Error', 'Something Wrong')
        }

          })


}//end




//BorrowBook
$(document).on("click", "#btnborrow", function(){
     
   $("#reserve").css("display", "none");
   $("#borrow").css({"display":"inline-block","width":"100%"});
    $("#return").css("display", "none");

    });

$(document).on("click", "#btnreserve", function(){
     
   $("#reserve").css({"display":"block","width":"100%"});
   $("#borrow").css("display", "none");
   $("#return").css("display", "none");

    });//End


//DeleteBook
function Delete(event){
     
    var data = new FormData(event.target);
    data.append("method","DeleteBook");
    axios.post("./switchcase.php",data)
    .then(function(response){
        if(response.data ==1){
         
            Swal.fire('Success!', 'Book deleted')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./editbook.php";
                  }
              })
                   
         }
              
        else{
            var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })
}//end




function Warning()
{
    Swal.fire({icon: 'error',text: 'Please Login First'})
}//end


function SaveInfo(event){
   
    var pass= document.getElementById('pass2').value ;
    var check=CheckPassword(pass);
   

    if(check==true)
    {
    var data = new FormData(event.target);
    data.append("method","saveInfo");
    axios.post("./switchcase.php",data)
    .then(function(response){
        if(response.data == 1){
            Swal.fire('Success', 'Created')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./profile2.php";
                  }
              })
                   
         }
         else if(response.data ==2){
             Swal.fire({icon: 'error',text: 'Username already existed'})
              Clearform();     

         }
         else if (response.data ==3)
         {
           Swal.fire({icon: 'error',text: 'This email is already in used'})
              Clearform(); 
         }
              
        else{
            var data=response.data;
            Swal.fire({icon: 'error',text: 'Something Wrong'})
        }

          })
}
else
{
    Swal.fire({icon: 'error',text: 'Invalid Password'})
    ClearPass();
}
}//end


function AddBook(event){
     
    var data = new FormData(event.target);
    data.append("method","AddBook");
    axios.post("./switchcase.php",data)
    .then(function(response){
        if(response.data ==1){
            Swal.fire('Success', 'Created')
                  .then(function(response){
                  if(response.isConfirmed){                                
                    window.location = "./addbook.php";
                  }
              })
                   
         }             
        else{
          var data=response.data;
            Swal.fire('Error', 'Something Wrong!')
        }

          })
}//end


function Complete(event)
{
    var data = new FormData(event.target);
    data.append("method","Complete");
    axios.post("./switchcase.php",data)
    .then(function(response){
        if(response.data == 1){
            Swal.fire(
                'Success',
                'Account Complete',
              ).then(function(response){
                  if(response.isConfirmed){

                    window.location = "./login.html";
                  }
              })
           
            
        }
        else{
             Swal.fire({icon: 'error',text: 'There is a problem!'})
        }
    }) 
}//end

function ClearPass()
{
  document.getElementById('pass2').value="";
}//end

function Clearform()
{
  document.getElementById('pass2').value="";
  document.getElementById('user2').value="";
  document.getElementById('email').value="";
}//end

function ClearLogin()
{
   document.getElementById('user1').value="";
  document.getElementById('pass1').value="";
}
//end

function AdminClearLogin()
{
  document.getElementById('adminuser').value="";
  document.getElementById('adminpass').value="";
}



 function CheckPassword(pass)
 {
    var passw=  /^[A-Za-z]\w{7,14}$/;
if(pass.match(passw)) 
{ 
return true;
}
else
{ 
return false;
}
}
//end

     


function Login(event)
{
    var data = new FormData(event.target);
    data.append("method","Login");
    axios.post("./switchcase.php",data)
    .then(function(response){
        if(response.data == 1){
            Swal.fire(
                'Success',
                'Login Successfully',
              ).then(function(response){
                  if(response.isConfirmed){

                    window.location = "./index_2.php";
                  }
              })
            
        }
         else if(response.data == 2){
            Swal.fire({icon: 'error',text: 'Please log out previous session'})
            .then(function(response){
                  if(response.isConfirmed){

                    window.location = "./login.html";
                  }
              })
            
        }

        else{
             Swal.fire({icon: 'error',text: 'Incorrect Pasword or Username'})
             ClearLogin();
        }
    }) 
}


function AdminLogin(event)
{
   
    var data = new FormData(event.target);
    data.append("method","AdminLogin");
    axios.post("./switchcase.php",data)
    .then(function(response){
        if(response.data == 1){
            Swal.fire(
                'Success',
                'Login Successfully',
              ).then(function(response){
                  if(response.isConfirmed){

                    window.location = "./admindashboard.php";
                  }
              })
            
        }
         else if(response.data == 2){
            Swal.fire({icon: 'error',text: 'Please log out previous session'})
            .then(function(response){
                  if(response.isConfirmed){

                    window.location = "./login.html";
                  }
              })
            
        }
        else{
             Swal.fire({icon: 'error',text: 'Incorrect Pasword or Username'})
             AdminClearLogin();
        }
    }) 
}




 
     

 

 




