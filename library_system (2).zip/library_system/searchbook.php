<?php

  $search = $_POST['search'];

  header("Location:./shop.php?search=".$search);


?>