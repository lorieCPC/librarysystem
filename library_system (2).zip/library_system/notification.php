<html>
<head>
	</head>
  
	<body>

          <a id="bell" class="shopping-cart" href='./profile.php'><i  class="fas fa-bell"></i></a>
    <?php
      require_once("./connect.php");
      $username=$_SESSION['username'];
       $notify=0;
       
    
      $con = new DbConnection();
      if($con->dbStatus() == 1){
      $db = $con->getCon();

      $sql = "SELECT status FROM `book_reservation` WHERE costumer_username='$username'";
       $result=$con->getData($sql);

       if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {

        if($row['status']==="Reserved")
        {

        $notify+=1;
   
   
            }
        }
    }
}
$con->dbClose();
        
    ?>

    <script>
      var notify="<?php echo $notify;?>";


      if(notify>0){
     document.getElementById("bell").style.color = "orange";
     }


    </script>


  

   
   

		</body>

	</html>