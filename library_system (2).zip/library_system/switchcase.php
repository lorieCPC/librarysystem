<?php
 require_once("./connect.php");
 

session_start();


 

   $method = $_POST['method'];
    if(function_exists($method)){
        call_user_func($method);
    }
 

  switch($method){ 

   case 'saveInfo':
        
        
        $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

              $email = $_POST['email'] ;
              $user2 = $_POST['user2'];
              $pass2 = $_POST['pass2'];

              $_SESSION['username']=$user2;
          
        $user="SELECT username FROM `costumer_information` WHERE username='$user2'";
        $email2="SELECT email FROM `costumer_information` WHERE email='$email'";

         $username=$con->getData($user);
         $useremail=$con->getData($email2);
          


          if ($username->num_rows > 0 && $useremail->num_rows >0)
           {
            $con->dbClose();
               echo 2;
           }
          else if ($useremail->num_rows >0)
          {
             $con->dbClose();
                echo 3;
          }
          else if ($username->num_rows > 0) {
               $con->dbClose();
                echo 2;
            }
          
        else 
        {
    
        $sql = "INSERT INTO `costumer_information` (email,username,password)
                 VALUES ('$email', '$user2', '$pass2')";
       
        if($db->query($sql)===true){               
                $con->dbClose();
                echo 1;
        }
        else{
             $con->dbClose();
            echo 0;
        }
    }
}
          

    break;


  case 'Login':
   
 $check=0;

  if(isset($_SESSION['username'])===true && isset($_SESSION['password'])===true)
  {
    $check+=2;
    echo $check;
  }
   else{
   $con = new DbConnection();
   if($con->dbStatus() == 1){
    $db = $con->getCon();

      $user1 = $_POST['user1'];
  
     $pass1 = $_POST['pass1'];
      

     $sql = "SELECT username,password FROM `costumer_information`";
     $result=$con->getData($sql);
   
     if ($result->num_rows > 0) {
     while($row=$result->fetch_assoc()) {
     $username1=$row['username'];
     $password1=$row['password']; 

     if($user1===$username1 && $pass1===$password1)
     {
      $check+=1;
        $_SESSION['username']=$user1;
         $_SESSION['password']=$pass1;
      break;
     }
   }
 }
   echo $check;
   $con->dbClose();
   
}
}

   
break;

case 'Complete':

$con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

            $lname=$_POST['lname'];
            $fname=$_POST['fname'];
            $mname=$_POST['mname'];
            $gender=$_POST['gender'];
            $age=$_POST['age'];
            $birthdate=$_POST['birthdate'];
            $contact=$_POST['contact'];
            $address=$_POST['address'];
            $user=$_SESSION['username'];
    
           
            $sql = "UPDATE `costumer_information` SET lastname='$lname',firstname='$fname',middlename='$mname',age='$age',birthdate='$birthdate',address='$address',contact='$contact',gender='$gender' WHERE username='$user'";

            if ($db->query($sql) === TRUE) {
            $con->dbClose();
             echo 1;
            } else {
            $con->dbClose();
            echo 0;            
                   }
 

}

break;

case 'CreateAdmin':

         error_reporting(0);
         $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

            $lname=$_POST['lastname'];
            $fname=$_POST['firstname'];
            $mname=$_POST['mname'];
            $address=$_POST['address'];
            $gender=$_POST['gender'];
            $email=$_POST['adminemail'];
            $contact=$_POST['contact'];
            $username=$_POST['adminusername'];
            $adminpassword=$_POST['password'];


            $user="SELECT username FROM `librarian_information` WHERE username='$username'";
           $email2="SELECT email FROM `librarian_information` WHERE email='$email'";

              $user3=$con->getData($user);
             $email3=$con->getData($email2);


            if ($user3->num_rows > 0 && $email3->num_rows >0)
           {
            $con->dbClose();
               echo 2;
           }
          else if ($user3->num_rows >0)
          {
             $con->dbClose();
                echo 2;
          }
          else if ($email3->num_rows > 0) {
               $con->dbClose();
                echo 3;
            }
            else 
        {
    $sql = "INSERT INTO `librarian_information` (lname,fname,mname,gender,address,email,contact,username,password)VALUES ('$lname', '$fname', '$mname', '$gender', '$address', '$email', '$contact', '$username', '$adminpassword')";

 
       
        if($db->query($sql)===true ){               
                $con->dbClose();
                echo 1;
        }
        else{
             $con->dbClose();
            echo 0;
        }
    }
}



break;

case 'AdminLogin':
$check=0;
if(isset($_SESSION['username'])===true && isset($_SESSION['password'])===true)
  {
    $check+=2;
    echo $check;
  }
  else{
 $con = new DbConnection();
   if($con->dbStatus() == 1){
    $db = $con->getCon();

     $adminuser = $_POST['adminuser'];
   
     $adminpass=$_POST['adminpass'];
    
     

     $sql = "SELECT username,password FROM `librarian_information`";
     $result=$con->getData($sql);
   
     if ($result->num_rows > 0) {
     while($row=$result->fetch_assoc()) {
     $username1=$row['username'];
     $password1=$row['password']; 

     if($adminuser===$username1 && $adminpass===$password1)
     {
      $check+=1; 
        $_SESSION['username']=$adminuser;
        $_SESSION['password']=$adminpass;

     
      break;
     }
   }
 }
   echo $check;
   $con->dbClose();
   
}
}
   
break;


 case 'AddBook':
 $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();

              $title=$_POST['title'];
              $publisher=$_POST['publisher'];
              $writer=$_POST['writer'];
              $department=$_POST['department'];
              $price=$_POST['price'];
              $rack=$_POST['rack'];
              $status='Free';
     

             
       
        $sql = "INSERT INTO `book_information`(book_title,book_publisher,book_writer,book_price,rack,book_department,book_status)
                 VALUES ('$title', '$publisher', '$writer', '$price' , '$rack', '$department', '$status')";
       
        if($db->query($sql)===true){
                $con->dbClose();
                echo 1;
        }
        else{
             $con->dbClose();
            echo  0;
        }
    
}

    break;


  case 'UpdateBook':

$con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();
 
        $id=$_POST['id'];


        $title=$_POST['title'];

        $publisher=$_POST['publisher'];

        $writer=$_POST['writer'];

        $department=$_POST['department'];

        $price=$_POST['price'];

        $rack=$_POST['rack'];

        $status=$_POST['status'];

        $sql = "UPDATE `book_information` SET book_title='$title',book_publisher='$publisher',book_writer='$writer',book_department='$department',book_price='$price',rack='$rack',book_status='$status' WHERE book_id=$id";
        
        if($status==="Free")
        {
           $reserve ="DELETE FROM `book_reservation` WHERE book_id=$id";
        }
        else
        {
        $reserve ="UPDATE `book_reservation` SET book_title='$title',book_price='$price',status='$status' WHERE book_id=$id";
      }

        if ($db->query($sql)===true && $db->query($reserve)===true) {

            echo 1;


        }

        else {

             echo 0;

        }

        $con->dbClose();

    }
  
   break;

   case 'DeleteBook':

   $con = new DbConnection();
          if($con->dbStatus() == 1){
            $db = $con->getCon();


        $id=$_POST['id_d'];


        $sql = "DELETE FROM `book_information` WHERE book_id=$id ";
        $reserve ="DELETE FROM `book_reservation` WHERE book_id=$id";

        if ($db->query($sql)===true && $db->query($reserve)) {

            echo 1;

        }

        else {

            echo 0;

        }

        $con->dbClose();

    }



break;

 }

 


?>